﻿using Microsoft.Extensions.DependencyInjection;

namespace ObjectComparer
{
    public static class Startup
    {
        public static IServiceCollection Configure(IServiceCollection services = null)
        {
            services = services ?? new ServiceCollection();

            services.AddSingleton<IComparer, ComparerReflection>();

            return services;
        }
    }
}
