﻿using System;

using System.Collections;
using System.Collections.Generic;

using System.Linq;

using System.Reflection;

using System.Threading.Tasks;

namespace ObjectComparer
{
    internal class ComparerReflection : IComparer
    {
        public Task<bool> CompareAsync<T>(T t1, T t2)
        {
            return Task.FromResult(AreObjectsEqual(t1, t2));
        }


        private static bool AreObjectsEqual(object objectA, object objectB, params string[] ignoreList)
        {
            bool result;

            if (objectA != null && objectB != null)
            {
                Type objectType;

                objectType = objectA.GetType();

                result = true;

                foreach (PropertyInfo propertyInfo in objectType.GetProperties(BindingFlags.Public | BindingFlags.Instance).Where(p => p.CanRead && !ignoreList.Contains(p.Name)))
                {
                    object valueA;
                    object valueB;

                    valueA = propertyInfo.GetValue(objectA, null);
                    valueB = propertyInfo.GetValue(objectB, null);

                    if (CanDirectlyCompare(propertyInfo.PropertyType))
                    {
                        if (!AreValuesEqual(valueA, valueB))
                        {
                            result = false;
                        }
                    }
                    else if (typeof(IEnumerable).IsAssignableFrom(propertyInfo.PropertyType))
                    {
                        IEnumerable<object> collectionItems1;
                        IEnumerable<object> collectionItems2;
                        int collectionItemsCount1;
                        int collectionItemsCount2;

                        if (valueA == null && valueB != null || valueA != null && valueB == null)
                        {
                            result = false;
                        }
                        else if (valueA != null && valueB != null)
                        {
                            collectionItems1 = ((IEnumerable)valueA).Cast<object>();
                            collectionItems2 = ((IEnumerable)valueB).Cast<object>();
                            collectionItemsCount1 = collectionItems1.Count();
                            collectionItemsCount2 = collectionItems2.Count();

                            if (collectionItemsCount1 != collectionItemsCount2)
                            {
                                result = false;
                            }
                        }
                    }
                    else if (propertyInfo.PropertyType.IsClass)
                    {
                        //Arbitrary case
                        if (!AreObjectsEqual(propertyInfo.GetValue(objectA, null), propertyInfo.GetValue(objectB, null), ignoreList))
                        {
                            result = false;
                        }
                    }
                    else
                    {
                        result = false;
                    }
                }
            }
            else
                result = Equals(objectA, objectB);

            return result;
        }

        private static bool CanDirectlyCompare(Type type)
        {
            return typeof(IComparable).IsAssignableFrom(type) || type.IsPrimitive || type.IsValueType;
        }

        private static bool AreValuesEqual(object valueA, object valueB)
        {
            bool result;
            IComparable selfValueComparer;

            selfValueComparer = valueA as IComparable;

            if (valueA == null && valueB != null || valueA != null && valueB == null)
                result = false;
            else if (selfValueComparer != null && selfValueComparer.CompareTo(valueB) != 0)
                result = false;
            else if (!Equals(valueA, valueB))
                result = false;
            else
                result = true;

            return result;
        }
    }
}
