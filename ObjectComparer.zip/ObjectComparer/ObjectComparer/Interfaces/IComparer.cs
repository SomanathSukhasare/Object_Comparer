﻿using System.Threading.Tasks;

namespace ObjectComparer
{
    public interface IComparer
    {
        Task<bool> CompareAsync<T>(T t1, T t2);
    }
}
