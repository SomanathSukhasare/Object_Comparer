﻿namespace ObjectComparer.Tests
{
    public class TestData
    {
        public class Student
        {
            public string Name { get; set; }
            public int Id { get; set; }
            public int[] Marks { get; set; }
        }
    }
}
