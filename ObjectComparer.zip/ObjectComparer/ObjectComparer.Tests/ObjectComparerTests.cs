using FluentAssertions;

using Microsoft.Extensions.DependencyInjection;

using System.Threading.Tasks;

using Xunit;

namespace ObjectComparer.Tests
{
    public class ObjectComparerTests
    {
        private readonly IComparer _comparer = null;
        public ObjectComparerTests()
        {
            var services = Startup.Configure();
            _comparer = services.BuildServiceProvider().GetService<IComparer>();
        }

        [Fact]
        
        public async Task Can_Compare_Similar_Objects()
        {
            var firstStudent = new TestData.Student
            {
                Name = "John",
                Id = 100,
                Marks = new[] { 80, 90, 100 }
            };

            var secondStudent = new TestData.Student
            {
                Name = "John",
                Id = 100,
                Marks = new[] { 80, 90, 100 }
            };

            var response = await _comparer.CompareAsync(firstStudent, secondStudent);

            response.Should().BeTrue();
        }

        [Fact]
        public async Task Can_Compare_Differently_Sorted_Objects()
        {
            var firstStudent = new TestData.Student
            {
                Name = "John",
                Id = 100,
                Marks = new[] { 80, 90, 100 }
            };

            var secondStudent = new TestData.Student
            {
                Name = "John",
                Id = 100,
                Marks = new[] { 100, 90, 80 }
            };

            var response = await _comparer.CompareAsync(firstStudent, secondStudent);

            response.Should().BeTrue();
        }

        [Fact]
        public async Task Can_Compare_Null_Objects()
        {
            TestData.Student firstStudent = null;
            TestData.Student secondStudent = null;

            var response = await _comparer.CompareAsync(firstStudent, secondStudent);

            response.Should().BeTrue();
        }

        [Fact]
        public async Task Can_Compare_Different_Objects()
        {
            var firstStudent = new TestData.Student
            {
                Name = "John",
                Id = 100,
                Marks = new[] { 80, 90, 100 }
            };

            var secondStudent = new TestData.Student
            {
                Name = "John",
                Id = 101,
                Marks = new[] { 80, 90, 100 }
            };

            var response = await _comparer.CompareAsync(firstStudent, secondStudent);

            response.Should().BeFalse();
        }

        [Fact]
        public async Task Can_Compare_Objects_With_Null()
        {
            var firstStudent = new TestData.Student
            {
                Name = "John",
                Id = 100,
                Marks = new[] { 80, 90, 100 }
            };

            TestData.Student secondStudent = null;

            var response = await _comparer.CompareAsync(firstStudent, secondStudent);

            response.Should().BeFalse();
        }

        [Fact]
        public async Task Can_Compare_Objects_With_Different_ArrayLength()
        {
            var firstStudent = new TestData.Student
            {
                Name = "John",
                Id = 100,
                Marks = new[] { 80, 90, 100 }
            };

            var secondStudent = new TestData.Student
            {
                Name = "John",
                Id = 100,
                Marks = new[] { 50, 60, 70, 80, 90, 100 }
            };

            var response = await _comparer.CompareAsync(firstStudent, secondStudent);

            response.Should().BeFalse();
        }

        [Fact]
        public async Task Can_Compare_Objects_With_Different_Cases()
        {
            var firstStudent = new TestData.Student
            {
                Name = "JOHN",
                Id = 100,
                Marks = new[] { 80, 90, 100 }
            };

            var secondStudent = new TestData.Student
            {
                Name = "john",
                Id = 100,
                Marks = new[] { 80, 90, 100 }
            };

            var response = await _comparer.CompareAsync(firstStudent, secondStudent);

            response.Should().BeFalse();
        }
    }
}
